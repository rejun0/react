import './App.css';

import { Pure , Shallow } from './05_PureComponent';

function App3() {
    return(
        //<Pure />
        <Shallow/>
    )
}

export default App3;